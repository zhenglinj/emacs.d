To use it, open a Python file and run M-x live-py-mode
If that doesn't work, put the following in your Emacs configuration file:

  (require 'live-py-mode)

Requirements: Emacs 24.

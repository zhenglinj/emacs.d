Overview
--------

`lice.el` provides following features:

- License template management.
- File header insertion.

Usage
-----

Usage is very easy, put `lice.el` in your emacs system, and open a new
file, and run:

    M-x lice

Then, `lice.el` tell to use which license (default is gpl-3.0). You
can select license on minibuffer completion.

When you select license, and enter the `RET`, license and copyright is
putted into a text.

More Information
----------------

See the `README.md` file for more information.

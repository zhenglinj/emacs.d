Customize `highlight-indentation-face', and
`highlight-indentation-current-column-face' to suit your theme.
